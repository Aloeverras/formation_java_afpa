package com.afpa.red_thread_entity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedThreadEntityApplicationTests {

	@Test
	void contextLoads() {
	}

}
